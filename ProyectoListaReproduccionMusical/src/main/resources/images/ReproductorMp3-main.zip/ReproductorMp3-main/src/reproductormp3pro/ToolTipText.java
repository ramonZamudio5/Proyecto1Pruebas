
package reproductormp3pro;

import javax.swing.JButton;

public class ToolTipText {

    public ToolTipText(JButton boton,String texto) {
        boton.setToolTipText(texto);
    }
    
}

