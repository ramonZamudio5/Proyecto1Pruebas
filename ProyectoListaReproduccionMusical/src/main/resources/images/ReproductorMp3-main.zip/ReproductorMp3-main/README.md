# ReproductorMp3
Reproductor Mp3 con Java Swing

Editor Usado Netbeans, pero se puede usar cualquier editor para programar con el, precisa de la libreria de netbeans 
que se encuentran en el directorio librerias hay que incluirlas a la hora de cargar el programa para que no de errores
librerias de sonido mas libreria AbsoluteLayout de netbeans.
El programa es un simple reproductor de audio formato mp3, con muchas funciones extra... difruten de su amplio codigo

El programa esta bastante mal estructurado ya que es uno de mis primeros proyectos y aun tenia basicos conocimientos de programacion...

![Captura de pantalla 2023-09-26 232737](https://github.com/Yacoobs76/ReproductorMp3/assets/144021540/e8c5d216-64c7-4e82-9c75-f1c920fb6eb0)
